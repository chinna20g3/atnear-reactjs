import React from "react";
import { Box, Paper, Container, Grid, Button, Typography } from "@mui/material";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import img1 from "../../assets/Rectangle 24.png";

const articles = [
  {
    image: img1,
  },
  {
    image: img1,
  },
  {
    image: img1,
  },
  {
    image: img1,
  },
];

const ArticleCard = ({ article }) => {
  return (
    <Paper
      elevation={3}
      sx={{
        borderRadius: "20px",
        backgroundColor: 'white',
        overflow: "hidden",
        width: '55%',
        marginLeft: '125px'
      }}
    >
      <Box
        sx={{
          height: "170px",
          overflow: "hidden",
        }}
      >
        <img
          src={article.image}
          alt="Trending Article"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            cursor: "pointer",
          }}
        />
      </Box>
    </Paper>
  );
};

const TrendingArticles = () => {
  return (
    <Box sx={{ py: 3, px: 5, backgroundColor: "#f7f7f7" }}>
      <Container maxWidth="lg">
        <Typography
          variant="h4"
          align="center"
          gutterBottom
          sx={{
            fontWeight: "bold",
            fontSize: { xs: "24px", sm: "25px" },
            color: "#333",
          }}
        >
          Latest Articles
        </Typography>
        <Grid container spacing={5} sx={{marginTop:'2px' }}>
          {articles.map((article, index) => (
            <Grid item xs={12} sm={6} key={index}>
              <ArticleCard article={article} />
            </Grid>
          ))}
        </Grid>
      </Container>
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          mt: 2,
        }}
      >
        <Button
          type="button"
          sx={{
            background: "#1D1A57",
            width: "160px",
            height: "42px",
            fontSize: "15px",
            color: "#F8F8F8",
            fontWeight: "600",
            borderRadius: "5px",
            mt: 4,
            "&:hover": {
              background: "#1D1A57",
            },
            "@media (min-width: 768px) and (max-width: 1024px)": {
              fontSize: "12px",
              fontWeight: "600",
              width: "133px",
            },
            "@media (min-width: 1024px) and (max-width:1440px)": {
              fontSize: "10px",
            },
          }}
        >
          Show All&nbsp;&nbsp;
          <ArrowForwardIcon />
        </Button>
      </Box>
    </Box>
  );
};

export default TrendingArticles;
