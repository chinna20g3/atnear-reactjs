import React from 'react';
import { Box, Typography, TextField, Button, InputAdornment } from '@mui/material';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import SearchIcon from '@mui/icons-material/Search';
import image from '../../assets/img1.jpg';

const Banner = () => {
    return (
        <Box sx={{ position: 'relative', width: '100%' }}>
            <img
                src={image}
                alt="Beautiful local scene"
                style={{
                    width: '100%',
                    height: 'auto',
                    maxHeight: '370px',
                    objectFit: 'cover',
                    display: 'block',
                }}
                aria-label="Local experience image"
            />
            <Box 
                sx={{
                    position: 'absolute',
                    top: '40%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)',
                    textAlign: 'center',
                    color: 'white',
                }}
            >
                <Typography
                    variant="h2"
                    sx={{
                        width: "100%",
                        fontWeight: "600",
                        fontSize: { xs: "16px", sm: "20px", md: "24px" },
                        lineHeight: { xs: "24px", sm: "30px", md: "36px" },
                    }}
                >
                    The Ultimate Local Experience: What’s Happening Near You
                </Typography>
                
                {/* Location and Search box */}
                <Box sx={{ marginTop: 2, display: 'flex', justifyContent: 'center', alignItems: 'center', gap:'40px' }}>
                    <TextField
                        placeholder="Select Location"
                        variant="outlined"
                        size="small"
                        sx={{
                            backgroundColor: 'white',
                            borderRadius: '4px',
                            width: { xs: '80%', sm: '50%', md: '40%' }
                        }}
                        InputProps={{
                            endAdornment: (
                                <InputAdornment position="end">
                                    <LocationOnIcon />
                                </InputAdornment>
                            ),
                        }}
                    />
                   <TextField
                        placeholder="Search for packers and movers..."
                        variant="outlined"
                        size="small"
                        sx={{
                            backgroundColor: 'white',
                            borderRadius: '4px',
                            width: { xs: '80%', sm: '50%', md: '50%' }
                        }}
                        InputProps={{
                            endAdornment: (
                                <InputAdornment position="end">
                                    <SearchIcon />
                                </InputAdornment>
                            ),
                        }}
                    />
                </Box>
            </Box>
        </Box>
    );
};

export default Banner;
