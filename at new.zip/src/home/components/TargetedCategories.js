import React from "react";
import { Box, Grid, Typography, Paper } from "@mui/material";
import img1 from "../../assets/2.webp";
import img2 from "../../assets/3.webp";
import img3 from "../../assets/4.webp";
import img4 from "../../assets/5.webp";
import img5 from "../../assets/6.webp";

const categories = [
    {
        title: "Wedding Requisites",
        items: [
            { name: "Banquet Halls", image: img1 },
            { name: "Bridal Requisite", image: img2 },
            { name: "Caterers", image: img3 },
        ],
    },
    {
        title: "Beauty & Spa",
        items: [
            { name: "Beauty Parlours", image: img1 },
            { name: " Massages", image: img2 },
            { name: "Salons", image: img3 },
        ],
    },
    {
        title: "Repairs & Services",
        items: [
            { name: "AC Service", image: img3 },
            { name: "Car Service", image: img4 },
            { name: "Bike Service", image: img5 },
        ],
    },
    {
        title: "Daily Needs",
        items: [
            { name: "Movies", image: img3 },
            { name: "Grocery", image: img4 },
            { name: "Electricians", image: img5 },
        ],
    },
];

const CategoryCard = ({ item }) => (
    <Paper
        elevation={3}
        sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            padding: 2,
            borderRadius: "12px",
            minWidth: "120px",
            height: "100px",
            textAlign: "center",
        }}
    >
        <Box
            component="img"
            src={item.image}
            alt={item.name}
            sx={{
                width: "100px",
                height: "80px",
                objectFit: "cover",
                borderRadius: "8px",
                mb: 1,
            }}
        />
        <Typography variant="body1" textAlign="center">
            {item.name}
        </Typography>
    </Paper>
);

const TargetedCategories = () => {
    return (
        <Grid container spacing={4} sx={{ py: 4, px: 6 }}>
            <Grid item xs={12} sx={{marginTop:4}}>
                <Grid container spacing={2} >
                    <Grid item xs={12} md={6} sx={{ border: '1px solid #ccc', borderRadius: '10px', py: 2 }}>
                        <Typography variant="h6" sx={{ mb: 2, fontWeight: "bold" }}>
                            Wedding Requisites
                        </Typography>
                        <Grid container spacing={2} sx={{ justifyContent: 'center', gap: '30px' }}>
                            {categories[0].items.map((item, idx) => (
                                <Grid item xs={12} sm={3} mb={2} key={idx}>
                                    <CategoryCard item={item} />
                                </Grid>
                            ))}
                        </Grid>
                    </Grid>

                    <Grid item xs={12} md={6} sx={{ border: '1px solid #ccc', borderRadius: '10px', py: 2 }}>
                        <Typography variant="h6" sx={{ mb: 2, fontWeight: "bold" }}>
                            Beauty & Spa
                        </Typography>
                        <Grid container spacing={2} sx={{ justifyContent: 'center', gap: '30px' }}>
                            {categories[1].items.map((item, idx) => (
                                <Grid item xs={12} sm={3} mb={2} key={idx}>
                                    <CategoryCard item={item} />
                                </Grid>
                            ))}
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>

            <Grid item xs={12} marginBottom={4} marginTop={2}>
                <Grid container spacing={2}>
                    <Grid item xs={12} md={6} sx={{ border: '1px solid #ccc', borderRadius: '10px', py: 2 }}>
                        <Typography variant="h6" sx={{ mb: 2, fontWeight: "bold" }}>
                            Repairs & Services
                        </Typography>
                        <Grid container spacing={2} sx={{ justifyContent: 'center', gap: '30px' }}>
                            {categories[2].items.map((item, idx) => (
                                <Grid item xs={12} sm={3} mb={2} key={idx}>
                                    <CategoryCard item={item} />
                                </Grid>
                            ))}
                        </Grid>
                    </Grid>

                    <Grid item xs={12} md={6} sx={{ border: '1px solid #ccc', borderRadius: '10px', py: 2 }}>
                        <Typography variant="h6" sx={{ mb: 2, fontWeight: "bold" }}>
                            Daily Needs
                        </Typography>
                        <Grid container spacing={2} sx={{ justifyContent: 'center', gap: '30px' }}>
                            {categories[3].items.map((item, idx) => (
                                <Grid item xs={12} sm={3} mb={2} key={idx}>
                                    <CategoryCard item={item} />
                                </Grid>
                            ))}
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    );
};

export default TargetedCategories;
